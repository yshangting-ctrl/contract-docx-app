# Contract DOCX App

合同与授权书 DOCX 编辑、生成和下载工具。前端使用 React + Vite，后端使用 Express + MongoDB。

本版本包含“开店授权”菜单，页面沿用“号卡联通”的字段编辑、批量识别、日期填充、历史记录与 Word 生成流程。

## 本地运行

要求：Node.js 20 LTS，MongoDB 6/7/8。

```bash
cd server
npm ci
npm run dev
```

另开终端：

```bash
cd client
npm ci
npm run dev
```

访问 `http://localhost:5173/`，后端健康检查为 `http://localhost:4000/api/health`。

## 环境变量

参考 `deploy/env.production.example` 创建 `server/.env`。不要把真实 `.env`、API Key 或 MongoDB 密码提交到仓库。

## 私有素材

GitHub 包刻意不包含真实合同 DOCX、签名和印章素材，以免公开仓库泄露公司、银行、联系人或印章信息。

本地或私有服务器运行前，请自行放置：

- 合同模板：`server/templates/`，文件名以 `server/src/config/contractFields.js` 中的 `fileName` 为准。
- 签名章素材：`client/public/downloads/签名和章素材.zip`。

生产服务器更新请使用单独的宝塔部署包，该包包含本次新增的生产模板和已构建前端。

## 构建

```bash
cd client
npm ci
npm run build
```

构建产物位于 `client/dist/`。Ubuntu/宝塔部署方式见 `deploy/nginx-baota.conf`、`deploy/ecosystem.config.cjs` 和生产更新包中的说明。

